import { NLParser, NLScorer } from './nl_engine.js';
export default class BrainlockApp {
  constructor(model, opts) {
    this.model = model; this.version = opts?.version || 'dev';
    this.ui = this.qs(); this.restore(); this.bind(); this.setTray('start'); this.updateHUD();
    this._audioReady = false; this.loadNL();
  }
  async loadNL(){ try{ const r=await fetch('./nl-tables.json'); const base=await r.json(); const ov=JSON.parse(localStorage.getItem('brainlock:nlTablesOverride')||'null'); this.nlTables=ov||base; }catch{ this.nlTables={}; } this.parser=new NLParser(this.nlTables); this.nl=new NLScorer(this.nlTables); }
  qs(){ const g=id=>document.getElementById(id); return {
    skateTop:g('skateTop'), trickText:g('trickText'), subText:g('subText'),
    levelBadge:g('levelBadge'), modeBadge:g('modeBadge'),
    scoreVal:g('scoreVal'), highVal:g('highVal'), streakVal:g('streakVal'),
    attemptDots:g('attemptDots'), scorePeek:g('scorePeek'),
    optionsBtn:g('optionsBtn'), endBtnModule:g('endBtnModule'),
    trayStart:g('trayStart'), trayActive:g('trayActive'), trayLanded:g('trayLanded'), trayMissed:g('trayMissed'), trayOver:g('trayOver'),
    startBtn:g('startBtn'), landBtn:g('landBtn'), missBtn:g('missBtn'), skipBtn:g('skipBtn'), nextBtnLanded:g('nextBtnLanded'), nextBtnMissed:g('nextBtnMissed'), restartBtn:g('restartBtn'),
    optionsDlg:g('optionsDlg'), closeOptions:g('closeOptions'), optTabs:g('optTabs'),
    levelRange:g('levelRange'), levelVal:g('levelVal'), soloCount:g('soloCount'), soloCountVal:g('soloCountVal'),
    stances:g('stances'), obstacles:g('obstacles'), catsWrap:g('catsWrap'),
    settingsBtn:g('settingsBtn'), settingsDlg:g('settingsDlg'), closeSettings:g('closeSettings'),
    scoreSpec:g('scoreSpec'), scoreNL:g('scoreNL'),
    importNLBtn:g('importNLBtn'), importNL:g('importNL'), resetNL:g('resetNL'),
    clearScores:g('clearScores'), clearCaches:g('clearCaches'),
    scoreDlg:g('scoreDlg'), closeScore:g('closeScore'), scoreOut:g('scoreOut'),
    dbgBtn:g('dbgBtn'), dbgDlg:g('dbgDlg'), closeDbg:g('closeDbg'), dbgOut:g('dbgOut'), whyOut:g('whyOut'), optOut:g('optOut'),
    soundBtn:g('soundBtn'),
    stackBtn:g('stackBtn'), stackDlg:g('stackDlg'), closeStack:g('closeStack'), stackInput:g('stackInput'), parseBtn:g('parseBtn'), useBtn:g('useBtn'), stackOut:g('stackOut')
  };}
  bind(){ const U=this.ui;
    U.optionsBtn.onclick=()=>U.optionsDlg.showModal(); U.closeOptions.onclick=()=>U.optionsDlg.close();
    U.optTabs.addEventListener('click',e=>{const t=e.target.closest('.tab'); if(!t) return; U.optTabs.querySelectorAll('.tab').forEach(x=>x.classList.remove('on')); t.classList.add('on'); const page=t.dataset.tab; document.querySelectorAll('.sheet-body').forEach(p=>p.classList.toggle('on', p.dataset.page===page));});
    U.levelRange.oninput=e=>{this.model.state.level=+e.target.value; U.levelVal.textContent=this.model.state.level; this.persist(); this.updateHUD();};
    U.soloCount.oninput=e=>{this.model.state.soloCount=+e.target.value; U.soloCountVal.textContent=this.model.state.soloCount; this.persist();};
    U.optionsDlg.querySelectorAll('[data-mode]').forEach(el=>{el.onclick=()=>{U.optionsDlg.querySelectorAll('[data-mode]').forEach(x=>x.classList.remove('on')); el.classList.add('on'); this.model.state.mode=el.dataset.mode; this.persist(); this.updateHUD();};});
    this.renderChips(U.stances, ['regular','fakie','nollie','switch'], this.model.state.stances);
    this.renderChips(U.obstacles, Object.keys(this.model.cfg?.obstacles||{flat:1}), this.model.state.obstacles);
    this.renderCategories();
    U.settingsBtn.onclick=()=>U.settingsDlg.showModal(); U.closeSettings.onclick=()=>U.settingsDlg.close();
    U.scoreSpec.onclick=()=>{ this.scoringEngine='spec'; localStorage.setItem('brainlock:engine','spec'); alert('Spec scoring enabled'); this.updateHUD(); };
    U.scoreNL.onclick=()=>{ this.scoringEngine='nl'; localStorage.setItem('brainlock:engine','nl'); alert('NL scoring enabled'); this.updateHUD(); };
    U.importNLBtn.onclick=()=>U.importNL.click();
    U.importNL.onchange=async(e)=>{ const f=e.target.files?.[0]; if(!f) return; try{ const txt=await f.text(); const obj=JSON.parse(txt); localStorage.setItem('brainlock:nlTablesOverride', JSON.stringify(obj)); alert('NL tables imported.'); await this.loadNL(); }catch(err){ alert('Invalid NL tables JSON'); } };
    U.resetNL.onclick=async()=>{ localStorage.removeItem('brainlock:nlTablesOverride'); await this.loadNL(); alert('NL tables reset.'); };
    U.clearScores.onclick=()=>{ localStorage.removeItem('brainlock:highscores'); this.high=[]; this.updateHUD(); alert('High scores cleared'); };
    U.clearCaches.onclick=async()=>{ if('caches' in window){ const keys=await caches.keys(); await Promise.all(keys.map(k=>caches.delete(k))); } alert('Cache cleared. Reload recommended.'); };
    U.startBtn.onclick=()=>this.startSession(); U.restartBtn.onclick=()=>this.startSession();
    U.landBtn.onclick=()=>this.land(); U.missBtn.onclick=()=>this.miss(); U.skipBtn.onclick=()=>this.skip();
    U.nextBtnLanded.onclick=()=>this.next(); U.nextBtnMissed.onclick=()=>this.next();
    U.scorePeek.onclick=()=>this.openScoreBreakdown();
    U.dbgBtn.onclick=()=>{ U.dbgDlg.showModal(); this.dumpWhy(); this.dumpOptions(); }; U.closeDbg.onclick=()=>U.dbgDlg.close();
    U.soundBtn.onclick=()=>{ this.enableSound(true); alert('Sounds ON. I will DING loudly when the session ends.'); };
    U.stackBtn.onclick=()=>U.stackDlg.showModal(); U.closeStack.onclick=()=>U.stackDlg.close();
    U.parseBtn.onclick=()=>this.parseStack(); U.useBtn.onclick=()=>this.useStackAsCurrent();
    this.scoringEngine = localStorage.getItem('brainlock:engine') || 'spec';
  }
  // helpers
  renderChips(container, labels, set){ container.innerHTML=''; labels.forEach(label=>{ const active=set.has(label); const chip=document.createElement('div'); chip.className='toggle'+(active?' on':''); chip.textContent=label; chip.onclick=()=>{ if(set.has(label)) set.delete(label); else set.add(label); chip.classList.toggle('on'); this.persist(); }; container.appendChild(chip); }); }
  renderCategories(){ const wrap=this.ui.catsWrap; wrap.innerHTML=''; const fams=['flips','grinds','manuals','spins']; const labels={flips:this.model.cfg?.families?.flips?.label||'Flip Tricks',grinds:'Grinds/Slides',manuals:'Manuals',spins:'Spins'}; fams.forEach(key=>{ const famOn=this.model.state.families.has(key); const head=document.createElement('div'); head.className='cat-head'; const toggle=document.createElement('div'); toggle.className='toggle'+(famOn?' on':''); toggle.textContent=labels[key]; toggle.onclick=()=>{ if(this.model.state.families.has(key)) this.model.state.families.delete(key); else this.model.state.families.add(key); toggle.classList.toggle('on'); subs.style.opacity=this.model.state.families.has(key)?'1':'.35'; this.persist(); }; head.appendChild(toggle); wrap.appendChild(head); const subs=document.createElement('div'); subs.className='subs'; subs.style.opacity=famOn?'1':'.35'; const sublist=Object.keys(this.model.cfg?.families?.[key]?.subs||{}); const set=this.model.state.sub[key]; sublist.forEach(name=>{ const chip=document.createElement('div'); const active=set.has(name); chip.className='toggle'+(active?' on':''); chip.textContent=name; chip.onclick=()=>{ if(!this.model.state.families.has(key)) return; if(set.has(name)) set.delete(name); else set.add(name); chip.classList.toggle('on'); this.persist(); }; subs.appendChild(chip); }); wrap.appendChild(subs); }); }
  setTray(state){ this.trayState=state; const vis=(el,on)=>el.classList.toggle('hidden',!on); vis(this.ui.trayStart,state==='start'); vis(this.ui.trayActive,state==='active'); vis(this.ui.trayLanded,state==='landed'); vis(this.ui.trayMissed,state==='missed'); vis(this.ui.trayOver,state==='over'); }
  formatLetters(n){ Array.from(this.ui.skateTop.children).forEach((s,i)=>s.classList.toggle('on', i<n)); }
  renderAttempts(){ const wrap=this.ui.attemptDots; wrap.innerHTML=''; const cur=Math.max(1,this.attempts||0); for(let i=1;i<=3;i++){ const dot=document.createElement('div'); dot.className='attempt-dot'; if(i===cur && this.trayState==='active') dot.classList.add('active'); if(this.missHistory?.includes(i)){ const m=document.createElement('div'); m.className='mark'; m.textContent='×'; dot.classList.add('missed'); dot.appendChild(m);} if(this.trayState==='landed' && this.landHistory?.includes(i)){ const m=document.createElement('div'); m.className='mark'; m.textContent='✓'; dot.classList.add('landed'); dot.appendChild(m);} wrap.appendChild(dot); } }
  restore(){ this.high=JSON.parse(localStorage.getItem('brainlock:highscores')||'[]'); const s=JSON.parse(localStorage.getItem('brainlock:settings')||'null'); if(s){ this.model.state.level=s.level??1; this.model.state.mode=s.mode??'SKATE'; this.model.state.soloCount=s.soloCount??10; this.model.state.stances=this.model.state.stances||new Set(['regular','fakie','nollie','switch']); this.updateSet(this.model.state.stances, s.stances||['regular','fakie','nollie','switch']); this.model.state.families=this.model.state.families||new Set(['flips','grinds','manuals','spins']); this.updateSet(this.model.state.families, s.families||['flips','grinds','manuals','spins']); this.model.state.obstacles=this.model.state.obstacles||new Set(Object.keys(this.model.cfg?.obstacles||{})); this.updateSet(this.model.state.obstacles, s.obstacles||Object.keys(this.model.cfg?.obstacles||{})); this.model.state.sub=this.model.state.sub||{}; this.model.state.sub.flips=this.model.state.sub.flips||new Set(); this.model.state.sub.grinds=this.model.state.sub.grinds||new Set(); this.model.state.sub.manuals=this.model.state.sub.manuals||new Set(); this.model.state.sub.spins=this.model.state.sub.spins||new Set(); if(s.sub){ this.updateSet(this.model.state.sub.flips, s.sub.flips||[]); this.updateSet(this.model.state.sub.grinds, s.sub.grinds||[]); this.updateSet(this.model.state.sub.manuals, s.sub.manuals||[]); this.updateSet(this.model.state.sub.spins, s.sub.spins||[]); } } }
  persist(){ const st=this.model.state; localStorage.setItem('brainlock:settings', JSON.stringify({ level:st.level, mode:st.mode, soloCount:st.soloCount, stances:[...st.stances], families:[...st.families], obstacles:[...st.obstacles], sub:{ flips:[...st.sub.flips], grinds:[...st.sub.grinds], manuals:[...st.sub.manuals], spins:[...st.sub.spins] } })); }
  updateSet(targetSet, arr){ if(!Array.isArray(arr)) return; targetSet.clear(); for(const x of arr) targetSet.add(x); }
  updateHUD(){ this.ui.levelBadge.textContent='Level '+this.model.state.level; this.ui.modeBadge.textContent='Mode: '+this.model.state.mode; this.ui.scoreVal.textContent=this.model.state.score; this.ui.highVal.textContent=(this.high?.[0]?.value)||0; this.ui.streakVal.textContent=this.model.state.flow; this.formatLetters(this.model.state.letters||0); this.renderAttempts(); const p=this.predictedScore(); this.ui.scorePeek.textContent=p?`This attempt: +${p.total}`:''; this.ui.endBtnModule.classList.toggle('hidden', !this.model.state.sessionActive); }
  async startSession(){
    await this.model.ready;
    // Apply saved settings in-place so chip event handlers remain valid
    const s=JSON.parse(localStorage.getItem('brainlock:settings')||'null');
    this.model.reset();
    if(s){
      this.model.state.level=s.level??this.model.state.level;
      this.model.state.mode=s.mode??this.model.state.mode;
      this.model.state.soloCount=s.soloCount??this.model.state.soloCount;
      this.updateSet(this.model.state.stances, s.stances||[...this.model.state.stances]);
      this.updateSet(this.model.state.families, s.families||[...this.model.state.families]);
      this.updateSet(this.model.state.obstacles, s.obstacles||[...this.model.state.obstacles]);
      if(s.sub){
        this.updateSet(this.model.state.sub.flips, s.sub.flips||[...this.model.state.sub.flips]);
        this.updateSet(this.model.state.sub.grinds, s.sub.grinds||[...this.model.state.sub.grinds]);
        this.updateSet(this.model.state.sub.manuals, s.sub.manuals||[...this.model.state.sub.manuals]);
        this.updateSet(this.model.state.sub.spins, s.sub.spins||[...this.model.state.sub.spins]);
      }
    }
    // Re-render chips so UI matches state
    this.renderChips(this.ui.stances, ['regular','fakie','nollie','switch'], this.model.state.stances);
    this.renderChips(this.ui.obstacles, Object.keys(this.model.cfg?.obstacles||{flat:1}), this.model.state.obstacles);
    this.renderCategories();
    // Start
    this.model.state.sessionActive=true; this.attempts=1; this.countDone=0; this.missHistory=[]; this.landHistory=[];
    this.pushNextTrick(); this.setTray('active'); this.updateHUD();
  }
  pushNextTrick(){ const t=this.model.selectTrick(); this.current=t; this.attempts=1; this.missHistory=[]; this.landHistory=[]; this.ui.trickText.textContent=this.model.trickText(t); this.ui.subText.textContent='Attempt 1 of 3'; this.updateHUD(); this.dumpWhy(); this.dumpOptions(); }
  dumpWhy(){ if(!this.ui.whyOut) return; this.ui.whyOut.textContent = 'Why this trick:\\n' + (this.model.state.why||''); this.ui.dbgOut.textContent = 'Build '+this.version; }
  dumpOptions(){ if(!this.ui.optOut) return; const st=this.model.state; const snap={ level:st.level, mode:st.mode, stances:[...st.stances], obstacles:[...st.obstacles], families:[...st.families], sub:{flips:[...st.sub.flips],grinds:[...st.sub.grinds],manuals:[...st.sub.manuals],spins:[...st.sub.spins]} }; this.ui.optOut.textContent='Options snapshot:\\n'+JSON.stringify(snap,null,2); }
  land(){ if(!this.current) return; const b=this.predictedScore(); this.model.state.score+=b.total; this.model.state.flow+=1; const key=this.current.signature||JSON.stringify(this.current); const count=(this.model.state.repeatMap.get(key)||0)+1; this.model.state.repeatMap.set(key,count); this.ui.subText.textContent=`+${b.total} (tap score for breakdown)`; this.landHistory.push(this.attempts); this.setTray('landed'); this.updateHUD(); }
  miss(){ if(!this.current) return; this.missHistory.push(this.attempts); if(this.attempts>=3){ this.model.state.flow=0; this.model.state.letters=Math.min(5,(this.model.state.letters||0)+1); this.ui.subText.textContent='Missed 3× → +1 letter'; if(this.model.state.mode==='SKATE' && (this.model.state.letters||0)>=5) return this.endSession(); this.setTray('missed'); } else { this.attempts+=1; this.ui.subText.textContent=`Miss (attempt ${this.attempts} of 3)`; this.setTray('active'); } this.updateHUD(); }
  skip(){ this.model.state.flow=0; this.ui.subText.textContent='Skipped'; this.next(); }
  next(){ if(this.model.state.mode==='SOLO'){ this.countDone=(this.countDone||0)+1; if(this.countDone>=this.model.state.soloCount) return this.endSession(); } this.pushNextTrick(); this.setTray('active'); }
  // audio
  enableSound(userGesture){ if(this._audioReady) return; const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return; this.ac=new AC(); this.master=this.ac.createGain(); this.master.gain.value=1.0; this.master.connect(this.ac.destination); const resume=()=>{ if(this.ac.state==='suspended') this.ac.resume(); }; if(userGesture) resume(); document.body.addEventListener('touchstart', resume, {once:true}); document.body.addEventListener('click', resume, {once:true}); this._audioReady=true; localStorage.setItem('brainlock:sound','1'); }
  tone(freq=880, dur=0.2, vol=1, type='sine'){ if(!this._audioReady) return; const o=this.ac.createOscillator(); const g=this.ac.createGain(); o.type=type; o.frequency.value=freq; o.connect(g); g.connect(this.master); const now=this.ac.currentTime; g.gain.setValueAtTime(0.0001, now); g.gain.linearRampToValueAtTime(0.25*vol, now+0.01); g.gain.exponentialRampToValueAtTime(0.0001, now+dur); o.start(now); o.stop(now+dur+0.05); }
  ding(){ this.tone(880,0.18,1,'triangle'); setTimeout(()=>this.tone(1320,0.14,1,'sine'),130); }
  endSession(){ const score=this.model.state.score; const entry={id:Date.now(), value:score, created_at:new Date().toISOString()}; this.high=this.high||[]; this.high.push(entry); this.high.sort((a,b)=>b.value-a.value); this.high=this.high.slice(0,100); localStorage.setItem('brainlock:highscores', JSON.stringify(this.high)); this.ui.trickText.textContent='Session Over'; this.ui.subText.textContent='Final: '+score+' — High: '+(this.high?.[0]?.value); this.model.state.sessionActive=false; this.setTray('over'); this.updateHUD(); this.ding(); }
  // scoring engines
  predictedScore(){ if(!this.current||!this.attempts) return null; if((localStorage.getItem('brainlock:engine')||'spec')==='nl'){ const key=this.current.signature||JSON.stringify(this.current); const n=(this.model.state.repeatMap.get(key)||0); const repeatM=(n<=2)?1:Math.max(0,1-.10*(n-2)); return this.nl.scoreStructured(this.current, this.attempts, this.model.state.flow, repeatM); } else { return this.model.scoreTrick(this.current, this.attempts); } }
  openScoreBreakdown(){ const b=this.predictedScore(); if(!b) return; const extra=((localStorage.getItem('brainlock:engine')||'spec')==='nl' && b.detail)?('\n\n'+b.detail):''; this.ui.scoreOut.textContent=['If you land now:',`Base: ${b.base?.toFixed?b.base.toFixed(2):b.base}`,`Combo: ×${b.combo?.toFixed?b.combo.toFixed(2):b.combo}`,`Attempt: ×${b.attemptM.toFixed(2)}`,`Flow: ×${b.flowM.toFixed(2)}`,`Repeat: ×${b.repeatM.toFixed(2)}`,`Total: ${b.total}`].join('\n')+extra; this.ui.scoreDlg.showModal(); this.ui.closeScore.onclick=()=>this.ui.scoreDlg.close(); }
  // Stack builder
  parseStack(){ const input=this.ui.stackInput.value||''; if(!input.trim()){ this.ui.stackOut.textContent='Type something like: Tre crook nollie bs flip out'; return; } const parsed=this.parser.parse(input); const parts=this.nl.evalParts(parsed); const lines=['TOKENS: '+(parsed.tokens.join(' ')),'STANCE: '+(parsed.stance||'regular'),'DIRECTION: '+(parsed.direction||'-'),'FLIPS: '+(parsed.flips.join(', ')||'-'),'GRIND: '+(parsed.grind||'-'),'MANUAL: '+(parsed.manual||'-'),'OBSTACLE: '+(parsed.obstacle||parsed.impliedObstacle||'-'),'','Breakdown:',parts.breakdown,'',`Score (NL base): ${parts.total.toFixed(2)}  [= (sum + bonus) × stance]`]; this.lastParsed={parsed, parts}; this.ui.stackOut.textContent=lines.join('\n'); }
  useStackAsCurrent(){ if(!this.lastParsed){ this.parseStack(); if(!this.lastParsed) return; } const p=this.lastParsed.parsed; const t={ obstacle:p.obstacle||p.impliedObstacle||'flat', stance:p.stance||'regular', pattern:'custom', flip:(p.flips[0]||null), grind:p.grind||null, manual:p.manual||null, direction:p.direction||null, spin:null }; t.signature=['stance','spin','flip','grind','manual','direction'].map(k=>(t[k]||'').toString().toLowerCase()).join('|'); this.current=t; this.attempts=1; this.missHistory=[]; this.landHistory=[]; this.ui.trickText.textContent=[t.stance!=='regular'?t.stance:null, t.spin?`${t.spin}°`:null, t.flip, t.direction?`${t.direction}`:null, t.grind, t.manual? (t.flip||t.grind? 'to '+t.manual : t.manual):null, 'on '+t.obstacle].filter(Boolean).join(' '); this.ui.subText.textContent='Custom trick — Attempt 1 of 3'; this.setTray('active'); this.updateHUD(); }
}